<?php /* 15 */

echo $_COOKIE['email']."<BR>";

echo $_COOKIE['senha'];


?>  