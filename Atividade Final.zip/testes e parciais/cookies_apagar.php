<?php /* 16 */
setcookie('email', time()-3600);
setcookie('senha', time()-3600);
?>  