<?php
require("conecta.php");

$nome = $_GET["nome"];
$email = $_GET["email"];
$senha = $_GET["senha"];
$confsenha = $_GET["confsenha"];
$hashsenha = trim(password_hash($senha,PASSWORD_DEFAULT));

try {
    $stmt = $conn->prepare("INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `hashsenha`) VALUES (NULL, :nome, :email, :senha, :hashsenha)");
    $stmt->bindParam("nome",$nome);
    $stmt->bindParam("email",$email);
    $stmt->bindParam("senha",$senha);
    $stmt->bindParam("hashsenha",$hashsenha);
       
    if($stmt->execute()){
        header("Location:formulario.php?msg1=ok&nome=$nome&email=$email&senha=$senha");
        }
        }
        catch(PDOException $e) {
	    $e->getMessage();    
    }
$conn = null;
$stmt = null;
?>