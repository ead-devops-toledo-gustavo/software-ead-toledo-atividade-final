<?php
$email = $_POST["loginemail"];
$senha = $_POST["loginsenha"];

if(isset($_POST["checkcookies"])){
  $scookies = $_POST["checkcookies"];
}
else{
  $scookies = "";
}

/*
echo "E-mail: ".$email."<br>";
echo "Senha: ".$senha."<br>";
echo "Cookies: ".$scookies."<br>";
*/

//funções
function validar_campo_vazio($email,$senha){
  $vazio = false;
  if ($email == "" || $senha == ""){
      $vazio = true;
      return $vazio;
  }
} 

function validar_email($email){  
  $valido = false;
  if(filter_var($email,FILTER_VALIDATE_EMAIL)){
      $valido = true;
  }
  return $valido;
} 

function validar_senha($senha) {
  $regra = '/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[a-zA-Z\d].\S{8,36}$/';
  $valido = false;
  if (preg_match($regra, $senha)){
      $valido = true;
  }  
  return $valido;
}
//Validar se a senha é válida
if (validar_senha($senha) == false){
  header("Location:login.php?email=$email&senhaval=$senha");
}

//Validar se o E-MAIL é valido
if (validar_email($email) == false){
  header("Location:login.php?&emailval=$email&senha=$senha");
}

//Validar se existe campo vazio
if (validar_campo_vazio($email,$senha) == true){
  header("Location:login.php?vemail=$email&vsenha=$senha");
}

//Validar se o cliente esta cadastrado no sistema.
if (validar_senha($senha) == true &&  
    validar_email($email) == true && 
    validar_campo_vazio($email,$senha) == false ) {
        
    require("conecta.php");

    try {
      $stmt = $conn->prepare("SELECT * FROM `usuarios` WHERE `email` = :email AND `senha` = :senha");
      $stmt->bindParam("email",$email); 
      $stmt->bindParam("senha",$senha);
      $stmt->execute();
    
      $res = $stmt->fetchAll();

      if(count($res) > 0) {
        foreach ($res as $row) {
          $nome = $row ['nome'];
          $email = $row ['email'];
          $senha = $row ['senha'];
          
          /*
          echo "$banco_nome <br>";
          echo "$banco_email <br>";
          echo "$banco_senha <br>";
          echo "LOGADO";
          */
          
          header("Location:perfil.php?nome=$nome&email=$email&senha=$senha");			
        }
      }
        else {
          //header("Location:cadastrar_usuario.php?nome=$nome&email=$email&senha=$senha&confsenha=$confsenha");			
          echo "DADOS DE ACESSO INVÁLIDO"; //
      }

    } catch(PDOException $e) {
      //echo $e->getMessage(); // eliminar esse echo quando for para produção.
    }
    }
    $conn = null;
?>
